import * as React from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  Image,
  FlatList,
  TextInput,
  ScrollView
} from 'react-native';
import Feather from 'react-native-vector-icons/Feather';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import subjectData from '../assets/data/subjectData'
import { useFonts } from 'expo-font';
import colors from '../assets/colors/colors';

export default About = ({ navigation }) =>{
  return(
    <View style={{alignItems: "center", justifyContent: "center", flex: 1, paddingHorizontal: 16}}>
      <Text style= {{textAlign: "center", fontFamily: "Georgia", fontSize: 20}}>
      TeamYeah merupakan sebuah alat IoT Pengontrol Suhu Air Kolam yang digunakan untuk menyelamatkan bibit ikan air tawar di bawah 2 bulan.
      </Text>
    </View>
  )
}