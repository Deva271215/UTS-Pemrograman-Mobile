import * as React from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  Image,
  FlatList,
  TextInput,
} from 'react-native';
import Feather from 'react-native-vector-icons/Feather';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import { useFonts } from 'expo-font';
import colors from '../assets/colors/colors';

export default SignIn = ({ navigation }) => {
  let [fontsLoaded] = useFonts({
    'Poppins': require('../assets/fonts/Poppins-Regular.ttf'),
    'Poppins-Bold': require('../assets/fonts/Poppins-Bold.ttf'),
    'Poppins-Light': require('../assets/fonts/Poppins-Light.ttf'),
  });

  const [email, onChangeEmail] = React.useState('');

  const [password, onChangePassword] = React.useState('');

  return (
    <View>
    <Image
       source = {require('../assets/images/logo.png')}
       style={{width: 300, height: 200}}
       resizeMode="contain"
      />
      <View style={styles.circleWrapper}>
      </View>
      <View style={styles.titleWrapper}>
        <Text style={styles.title} >{"ようこそ"}</Text>
        <Text style={styles.subTitle}>
          {'We miss you so much'}
        </Text>
      </View>
      <View style={styles.formWrapper}>
        <View style={styles.emailWrapper}>
          <Text style={styles.emailText}>Please insert email</Text>
          <View style={styles.emailInputWrapper}>
            <TextInput
              style={styles.emailInput}
              onChangeText={(text) => onChangeEmail(text)}
              value={email}
            />
          </View>
        </View>
        <View style={styles.passwordWrapper}>
          <Text style={styles.passwordText}>Please put your password here</Text>
          <View style={styles.passwordInputWrapper}>
            <TextInput
              style={styles.passwordInput}
              onChangeText={(text) => onChangePassword(text)}
              value={password}
            />
          </View>
        </View>
      </View>
      <TouchableOpacity onPress={()=>navigation.navigate('Main')}>
        <View style={styles.buttonWrapper}>
          <View style={styles.button}>
            <Text style={styles.textButton}>Sign In</Text>
          </View>
        </View>
      </TouchableOpacity>
      <View style={styles.footerWrapper}>
        <Text style={styles.firstText}>
          {"アカウントを持っていませんか?"}
          <TouchableOpacity onPress={()=>navigation.navigate('SignUp')}>
            <Text style={styles.secondText}>
            {"   Sign Up"}
             </Text>
          </TouchableOpacity>
        </Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  circleWrapper: {
    alignItems: 'center',
  },
  logo: {
    width: 65,
    height: 65,
    position: 'absolute',
    left: 18,
    top: 15,
  },
  titleWrapper: {
    marginTop: 20,
    alignItems: 'center',
  },
  title: {
    fontSize: 60,
    color: colors.background,
    fontWeight: 'bold',
  },
  subTitle: {
    marginTop: 10,
    letterSpacing: 0.4,
    fontFamily: 'lucida handwriting',
    color: colors.black,
    fontSize: 20,
  },
  formWrapper: {
    marginTop: 30,
    marginHorizontal: 20,
  },
  emailText: {
    fontFamily: 'Georgia',
    marginBottom: 10,
    color: colors.grey
  },
  emailInput: {
    height: 40,
    borderBottomColor: 'red',
    borderBottomWidth: 2,
  },
  passwordIcon: {
    position: 'absolute',
  },
  passwordText: {
    fontFamily: 'Georgia',
    marginBottom: 10,
    color: colors.grey,
    marginTop: 10
  },
  passwordInput: {
    height: 40,
    borderBottomColor: 'red',
    borderBottomWidth: 2,
  },
  buttonWrapper: {
    alignItems: 'center',
    marginTop: 30
  },
  button: {
    backgroundColor: "blue",
    paddingVertical: 20,
    paddingHorizontal: 100,
    borderRadius: 5
  },
  textButton: {
    color: colors.white,
    fontFamily: 'Georgia',
    fontSize: 16
  },
  footerWrapper: {
    alignItems: 'center',
    marginTop: 20
  },
  firstText: {
    fontFamily: 'Georgia',
    paddingRight: 10
  },
  secondText: {
    color: colors.background
  }
});
