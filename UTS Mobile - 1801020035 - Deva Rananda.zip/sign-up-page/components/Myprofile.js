import * as React from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  Image,
  FlatList,
  TextInput,
  ScrollView
} from 'react-native';
import Feather from 'react-native-vector-icons/Feather';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import subjectData from '../assets/data/subjectData'
import { useFonts } from 'expo-font';
import colors from '../assets/colors/colors';

const Myprofile=({navigation})=>{
  return(
    <View>
      <View style={{justifyContent: "space-between", flexDirection: "row", alignItems: "center"}}>
          <View>
          <Text style={{borderWidth: 1, borderColor: "red"}}>Deva Rananda</Text>
          <Text style={{borderWidth: 1, borderColor: "red"}}>devaputra78@gmail.com</Text>
          <Text style={{borderWidth: 1, borderColor: "red"}}>081355666969</Text>
          <Text style={{borderWidth: 1, borderColor: "red"}}>Jalan Sentosa, gg: Abadi, No: 19</Text>
          </View>
        <Image
          style={{width: 100, height: 100, }} source={require('../assets/images/main/user.png')}
      /></View>
    </View>
  )
}

export default Myprofile;
