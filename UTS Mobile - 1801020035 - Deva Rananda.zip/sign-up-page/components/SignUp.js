import * as React from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  Image,
  FlatList,
  TextInput,
} from 'react-native';
import Feather from 'react-native-vector-icons/Feather';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import { useFonts } from 'expo-font';
import colors from '../assets/colors/colors';

export default SignUp = ({ navigation }) => {
  let [fontsLoaded] = useFonts({
    'Poppins': require('../assets/fonts/Poppins-Regular.ttf'),
    'Poppins-Bold': require('../assets/fonts/Poppins-Bold.ttf'),
    'Poppins-Light': require('../assets/fonts/Poppins-Light.ttf'),
  });

  const [email, onChangeEmail] = React.useState('');

  const [mail, onChangeMail] = React.useState('');

  const [password, onChangePassword] = React.useState('');

  return (
    <View>
      <View style={styles.titleWrapper}>
        <Text style={styles.title}>Create your account</Text>
      </View>
      <View style={styles.circleWrapper}>
        <View style={styles.whiteCircle}>
          <Image
            style={styles.logo}
            source={require('../assets/images/logo.png')}
          />
        </View>
      </View>
      <View style={styles.formWrapper}>
        <View style={styles.emailWrapper}>
          <Text style={styles.emailText}>Your Username</Text>
          <View style={styles.emailInputWrapper}>
            <TextInput
              style={styles.emailInput}
              onChangeText={(text) => onChangeEmail(text)}
              value={email}
            />
          </View>
        </View>
        <View style={styles.passwordWrapper}>
          <Text style={styles.passwordText}>Your E-mail</Text>
          <View style={styles.passwordInputWrapper}>
            <TextInput
              style={styles.passwordInput}
              onChangeText={(text) => onChangeMail(text)}
              value={mail}
            />
          </View>
        </View>
        <View style={styles.passwordWrapper}>
          <Text style={styles.passwordText}>Your password</Text>
          <View style={styles.passwordInputWrapper}>
            <TextInput
              style={styles.passwordInput}
              onChangeText={(text) => onChangePassword(text)}
              value={password}
            />
          </View>
        </View>
      </View>
      <View style={styles.buttonWrapper}>
        <View style={styles.button}>
          <Text style={styles.textButton}>Sign Up</Text>
        </View>
      </View>
      <View style={styles.footerWrapper}>
        <Text style={styles.firstText}>
          Already have an account?
          <TouchableOpacity onPress={()=>navigation.navigate('SignIn')}>
          <Text style={styles.secondText}>
            {"  Sign In"}
          </Text>
        </TouchableOpacity>
        </Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  title: {
    textAlign: "center",
    color: colors.black,
    marginTop: 20,
    fontSize: 25,
    fontWeight: '900',
    fontFamily: "Georgia",
  },
  subTitle: {
    position: 'absolute',
    top: -150,
    left: 90,
    color: colors.white,
    fontFamily: 'Georgia',
    fontSize: 13
  },
  circleWrapper: {
    alignItems: 'center',
  },
  logo: {
    width: 130,
    height: 120,
    resizeMode: "contain",
  },
  whiteCircle: {
    backgroundColor: colors.white,
    marginTop: 65,
    width: 150,
    height: 150,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 50,
  },
  formWrapper: {
    marginTop: 30,
    marginHorizontal: 20,
  },
  emailText: {
    fontFamily: 'Georgia',
    marginBottom: 10,
    color: colors.grey
  },
  emailInput: {
    height: 40,
    borderBottomColor: 'red',
    borderBottomWidth: 2,
  },
  passwordText: {
    fontFamily: 'Georgia',
    marginBottom: 10,
    color: colors.grey,
    marginTop: 10
  },
  passwordInput: {
    height: 40,
    borderBottomColor: 'red',
    borderBottomWidth: 2,
  },
  buttonWrapper: {
    alignItems: 'center',
    marginTop: 30
  },
  button: {
    backgroundColor: "blue",
    paddingVertical: 20,
    paddingHorizontal: 100,
    borderRadius: 5
  },
  textButton: {
    color: colors.white,
    fontFamily: 'Georgia',
    fontSize: 16
  },
  footerWrapper: {
    alignItems: 'center',
    marginTop: 20
  },
  firstText: {
    fontFamily: 'Georgia',
    paddingRight: 10
  },
  secondText: {
    color: colors.background
  }
});
