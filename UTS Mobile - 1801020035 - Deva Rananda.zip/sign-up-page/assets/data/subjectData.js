const subjectData = [
  {
    id: '1',
    image: require('../images/main/math.png'),
    title: 'Math',
  },
  {
    id: '2',
    image: require('../images/main/language2.png'),
    title: 'Language',
  },
  {
    id: '3',
    image: require('../images/main/science.png'),
    title: 'Science',
  },
  {
    id: '4',
    image: require('../images/main/medicine.png'),
    title: 'Medicine',
  },
];

export default subjectData;