const classData = [
  {
    id: '1',
    image: require('../images/book/algebra.png'),
    title: 'Algebra 2',
    time: '2 hours'
  },
  {
    id: '2',
    image: require('../images/book/science.png'),
    title: 'Chemistry 1',
    time: '1 hours'
  },
  {
    id: '3',
    image: require('../images/book/math.png'),
    title: 'Calculus 1',
    time: '2 hours'
  },
  {
    id: '4',
    image: require('../images/main/language2.png'),
    title: 'Language',
    time: '2 hours'
  },
  {
    id: '5',
    image: require('../images/main/medicine.png'),
    title: 'Medicine',
    time: '2 hours'
  },
];

export default classData;