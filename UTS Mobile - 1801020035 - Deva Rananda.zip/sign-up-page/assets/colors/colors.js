const colors = {
  background: '#0274BC',
  darkBlue: '#005F9B',
  lightBlue: '#B1EAFD',
  green: '#2F9055',
  lightGreen: '#589A12',
  yellow: '#FD8700',
  black: '#000000',
  grey: '#838383',
  white: '#FFFFFF',
  lightGrey: '#F6F6F6',
  creamBlue: '#F5F9FA'
};

export default colors;